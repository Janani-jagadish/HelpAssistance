package com.example.helpassistance.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.helpassistance.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class SignupActivity extends AppCompatActivity {

    EditText username_edt, email_edt, contact_edt, speciality_edt, experience_edt, vehicle_no_edt, password_edt;
    Button sign_up_btn;
    TextView go_to_login;
    ProgressDialog progressDialog;
    RadioGroup roleGroup;
    RadioButton radioUser, radioHelper;
    LinearLayout helperFieldsLayout;

    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize views
        username_edt = findViewById(R.id.username_edt);
        email_edt = findViewById(R.id.email_edt);
        contact_edt = findViewById(R.id.contact_edt);
        speciality_edt = findViewById(R.id.speciality_edt);
        experience_edt = findViewById(R.id.experience_edt);
        vehicle_no_edt = findViewById(R.id.vehicle_no_edt);
        password_edt = findViewById(R.id.password_edt);
        sign_up_btn = findViewById(R.id.sign_up_btn);
        go_to_login = findViewById(R.id.go_to_login);

        roleGroup = findViewById(R.id.roleGroup);
        radioUser = findViewById(R.id.radioUser);
        radioHelper = findViewById(R.id.radioHelper);
        helperFieldsLayout = findViewById(R.id.helperFieldsLayout);

        progressDialog = new ProgressDialog(this);
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("users");

        // Show/hide helper fields based on role selection
        roleGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioHelper) {
                helperFieldsLayout.setVisibility(View.VISIBLE);
            } else {
                helperFieldsLayout.setVisibility(View.GONE);
            }
        });

        // Signup button click
        sign_up_btn.setOnClickListener(v -> signupUser());

        // Go to login click
        go_to_login.setOnClickListener(v ->
                startActivity(new Intent(SignupActivity.this, LoginActivity.class))
        );
    }

    private void signupUser() {
        String name = username_edt.getText().toString().trim();
        String email = email_edt.getText().toString().trim();
        String contact = contact_edt.getText().toString().trim();
        String speciality = speciality_edt.getText().toString().trim();
        String experience = experience_edt.getText().toString().trim();
        String vehicleNo = vehicle_no_edt.getText().toString().trim();
        String password = password_edt.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Email and Password are required", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.setMessage("Registering...");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    progressDialog.dismiss();
                    if (task.isSuccessful()) {
                        String uid = firebaseAuth.getCurrentUser().getUid();

                        // Get role from RadioGroup
                        int selectedRoleId = roleGroup.getCheckedRadioButtonId();
                        String role = (selectedRoleId == R.id.radioHelper) ? "Helper" : "User";

                        // Create user map
                        HashMap<String, Object> userMap = new HashMap<>();
                        userMap.put("name", name);
                        userMap.put("email", email);
                        userMap.put("contact", contact);
                        userMap.put("role", role);

                        // Add helper-specific fields only if role is Helper
                        if (role.equals("Helper")) {
                            userMap.put("speciality", speciality);
                            userMap.put("experience", experience);
                            userMap.put("vehicleNo", vehicleNo);
                        }

                        // Save to Firebase
                        databaseReference.child(uid).setValue(userMap)
                                .addOnCompleteListener(dbTask -> {
                                    if (dbTask.isSuccessful()) {
                                        Toast.makeText(SignupActivity.this, "Signup successful!", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(SignupActivity.this, LoginActivity.class));
                                        finish();
                                    } else {
                                        Toast.makeText(SignupActivity.this, "Failed to save user: " + dbTask.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });

                    } else {
                        Toast.makeText(SignupActivity.this, "Signup failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
