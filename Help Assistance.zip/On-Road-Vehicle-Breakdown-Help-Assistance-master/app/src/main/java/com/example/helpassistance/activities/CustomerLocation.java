package com.example.helpassistance.activities;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;

import com.example.helpassistance.R;
import com.example.helpassistance.helpers.Config;
import com.example.helpassistance.models.Helper;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class CustomerLocation extends AppCompatActivity implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    private FirebaseUser user;
    private LocationManager locationManager;
    private LatLng yourLocation;
    private Map<Marker, Helper> markerHelperMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_location);

        // Load the map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        user = FirebaseAuth.getInstance().getCurrentUser();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        updateLocationUI();

        // When user clicks a helper marker, show details
        mMap.setOnMarkerClickListener(marker -> {
            Helper helper = markerHelperMap.get(marker);
            if (helper != null) {
                showHelperDetails(helper);
            }
            return false;
        });
    }

    private void updateLocationUI() {
        if (mMap != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {

                // Request location permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                        1);
            } else {
                Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (location != null) {
                    showUserLocation(location);
                } else {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 10, this);
                }
            }
        }
    }

    private void showUserLocation(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        yourLocation = new LatLng(latitude, longitude);

        // Show user marker
        mMap.addMarker(new MarkerOptions().position(yourLocation).title("You are here"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(yourLocation, 14.0f));

        // Fetch helper1 location
        fetchHelper1Location();
    }

    private void fetchHelper1Location() {
        Config.helper_db.child("helper1").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mMap.clear(); // Clear previous markers
                if (yourLocation != null) {
                    mMap.addMarker(new MarkerOptions().position(yourLocation).title("You are here"));
                }
                markerHelperMap.clear();

                Helper helper = snapshot.getValue(Helper.class);
                if (helper != null && helper.getLatitude() != 0 && helper.getLongitude() != 0) {
                    LatLng helperLocation = new LatLng(helper.getLatitude(), helper.getLongitude());
                    Marker marker = mMap.addMarker(new MarkerOptions()
                            .position(helperLocation)
                            .title("Helper: " + helper.getName()));
                    markerHelperMap.put(marker, helper);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CustomerLocation.this, "Failed to load helper1", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showHelperDetails(Helper helper) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.info_dialog);
        dialog.setCancelable(true);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView hName = dialog.findViewById(R.id.h_name);
        hName.setText(helper.getName());

        // Hide unused fields
        TextView hEmail = dialog.findViewById(R.id.h_email);
        TextView hNum = dialog.findViewById(R.id.h_num);
        TextView hStatus = dialog.findViewById(R.id.h_status);
        hEmail.setVisibility(View.GONE);
        hNum.setVisibility(View.GONE);
        hStatus.setVisibility(View.GONE);

        AppCompatButton btnCall = dialog.findViewById(R.id.call_helper);
        btnCall.setVisibility(View.GONE);

        dialog.show();
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        showUserLocation(location);
    }
}
