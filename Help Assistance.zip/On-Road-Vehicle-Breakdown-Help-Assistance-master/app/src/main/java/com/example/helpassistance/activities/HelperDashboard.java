package com.example.helpassistance.activities;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.helpassistance.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HelperDashboard extends AppCompatActivity {

    private Button checkCustomerLoc;
    private DatabaseReference databaseHelper; // Firebase reference

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_helper_dashboard);

        checkCustomerLoc = findViewById(R.id.btn_check_customer_loc);

        // Firebase reference points to "helpers" node
        databaseHelper = FirebaseDatabase.getInstance().getReference("helpers");

        checkCustomerLoc.setOnClickListener(v -> {
            Dialog dialogCheck = new Dialog(this);
            dialogCheck.setContentView(R.layout.check_loc_dialog);
            dialogCheck.setCancelable(true);
            dialogCheck.getWindow().setLayout(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );

            Button btnCheck = dialogCheck.findViewById(R.id.btnCheck);
            EditText edtHelperId = dialogCheck.findViewById(R.id.helperEmail);

            btnCheck.setOnClickListener(v1 -> {
                String helperId = edtHelperId.getText().toString().trim(); // User enters "helper1"
                if (helperId.isEmpty()) {
                    edtHelperId.setError("Please enter Helper ID (e.g., helper1)");
                } else {
                    // Fetch data for that helperId
                    databaseHelper.child(helperId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                Double latitude = snapshot.child("latitude").getValue(Double.class);
                                Double longitude = snapshot.child("longitude").getValue(Double.class);
                                String arrivalTime = snapshot.child("arrivalTime").getValue(String.class);

                                // Pass to CustomerLocation activity
                                Intent i = new Intent(HelperDashboard.this, CustomerLocation.class);
                                i.putExtra("latitude", latitude);
                                i.putExtra("longitude", longitude);
                                i.putExtra("arrivalTime", arrivalTime);
                                startActivity(i);

                                dialogCheck.dismiss();
                            } else {
                                edtHelperId.setError("Helper not found!");
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            edtHelperId.setError("Error: " + error.getMessage());
                        }
                    });
                }
            });

            dialogCheck.show();
        });
    }
}
