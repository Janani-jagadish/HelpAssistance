package com.example.helpassistance.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.helpassistance.R;


public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button btnHelper = findViewById(R.id.btnHelper);
        Button btnCustomer = findViewById(R.id.btnCustomer);

        btnHelper.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.putExtra("role", "helper");
            startActivity(intent);
        });

        btnCustomer.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.putExtra("role", "customer");
            startActivity(intent);
        });
    }
}
